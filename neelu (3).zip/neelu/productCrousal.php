
<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
//echo "select distinct prod_category,prod_name,prod_briefdes, photo1 from product  where userid=".$userid." group by prod_category";
$result = $conn->query("select prod_group, prod_group_name,prod_gdes, photo1 from product  where userid=".$userid."  group by prod_group limit 8");

$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
       $outp .= '{"cat_id":"'  . $row["prod_group"] . '",';
       $outp .= '"p_name":"'  . $row["prod_group_name"] . '",';
       $outp .= '"p_img":"'  . $row["photo1"] . '",';
	   $outp .= '"prod_des":"'.preg_replace("/[\r\n]+/", "<br />", $row["prod_briefdes"]).'"}'; 
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
