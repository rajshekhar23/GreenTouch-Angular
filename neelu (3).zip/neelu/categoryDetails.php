<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
//echo "Select cat_name, \"\" as desc from sub_category where id =".$_GET['categoryId'];
$id = $_GET['categoryId'];
$query = "Select distinct prod_group_name, prod_gdes as description from product where prod_status=1 and prod_group ='".$id."'";
$result = $conn->query($query);

$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
       $outp .= '{"cat_desc":"'  . $row["description"] . '",';
	   $outp .= '"cat_name":"'. $row["prod_group_name"]     . '"}'; 
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
