
<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
$name = $_GET['name'];
$phone = $_GET['phone'];
$email = $_GET['email'];
$message = $_GET['message'];

if ($result = mysqli_query($conn,"SELECT email from register where id='".$userid."'"))
{
    $row = $result->fetch_array(MYSQLI_ASSOC);
    $to_mail = $row['email'];
	$query = "insert into enquiries(name,phone,to_mail,from_mail,email,msg) values('$name','$phone','$to_mail','$email','$email','$message')";
	if(mysqli_query($conn,$query)){
		$someJSON = '[{"name":"'.$name.'","message":"Successfully submitted"}]';
		$myJSON = json_encode($someJSON);
		echo $myJSON;	
	}
	else
	{
		$someJSON = '[{"name":"'.$name.'","message":"'. mysqli_error($conn) .'"}]';
		$myJSON = json_encode($someJSON);
		echo $myJSON;
	}

}

$conn->close();
?>
