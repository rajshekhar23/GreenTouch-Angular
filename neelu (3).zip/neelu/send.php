<?php
	mail('rajb2381991@gmail.com', 'Subject Line Here', 'Body of Message Here', 'From: rajb2381991@gmail.com');
?>