<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
$id = $_GET['categoryId'];

$result = $conn->query("select userid, prod_group_name,prod_name,unit_price,prod_gdes,photo1,
prod_quantitytype,unit_price_unit,prod_briefdes from product where prod_status=1 and userid=".$userid." and prod_group=".$id." group by prod_group");

$res = [];

if(mysqli_num_rows($result) > 0){
		while($row = $result->fetch_array(MYSQLI_ASSOC)) {
			$res[] = $row;
		}
		echo json_encode($res);
	} else {
		echo json_encode($res);
	}
	$conn->close();
?>
