<?php

require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$query1 = "select id,prod_group,prod_grp_id,prod_group_name,prod_name from product where userid='".$userid."'"; 

$result1 = $conn->query($query1);

while($r1 = mysqli_fetch_assoc($result1)) {
	$rows1[] = $r1;
}
echo json_encode($rows1);
$conn->close();
?>
