<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$cat_name_search_text = $_GET['catsearch'];

$result = $conn->query("select  prod_group,prod_name from product p where p.prod_name like '%$cat_name_search_text%' 
and p.userid=".$userid." group by prod_group");

//echo "select  prod_group,prod_name from product p where p.prod_name like '%$cat_name_search_text%' and p.userid=".$userid." group by prod_group";

$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
       $outp .= '{"cat_id":"'  . $row["prod_group"] . '",';
	   $outp .= '"cat_name":"'. $row["prod_name"]     . '"}'; 
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
