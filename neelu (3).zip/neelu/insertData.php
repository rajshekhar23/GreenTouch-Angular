<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods:GET,POST,PUT,DELETE,OPTIONS");

header("Access-Control-Allow-Headers:  content-type,accept");
$request_body = file_get_contents('php://input');
$data = json_decode($request_body);

$r=0;
foreach ($data as $tweet) {
    $user = $tweet["name"];
   // echo $user;
    echo $tweet.'kk';
    
    $req[$r]=$tweet;
    $r++;
    
}
var_dump($req);

 echo "id ".$id  . "msg".$msg;
echo "insert into insertData(message, id, name) values ('".$req[1]."','".$req[0]. "','".$req[2]. "')";

$result = $conn->query("insert into insertData(message, id, name) values ('".$req[1]."','".$req[0]. "','".$req[2]. "')");

$outp = "";

$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
