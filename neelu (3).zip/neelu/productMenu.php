
<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

//echo "select  prod_group,prod_group_name from product p where p.userid=".$userid."group by prod_group";
$result = $conn->query("select  prod_group,prod_group_name from product p where p.userid=".$userid." group by prod_group");

$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
       $outp .= '{"cat_id":"'  . $row["prod_group"] . '",';
	   $outp .= '"cat_name":"'. $row["prod_group_name"]     . '"}'; 
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
