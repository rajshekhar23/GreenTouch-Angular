
<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
if ($result = mysqli_query($conn,"SELECT email from register where id='".$userid."'"))
{
    $row = $result->fetch_array(MYSQLI_ASSOC);
    $owner_mail = $row['email'];
}
$result = $conn->query("select phone, name, street,state_name,nicename,zip_code,city_name from company c join countries co on co.id=c.id join states s on s.state_id=c.state join city ct on ct.state_auto_id = s.state_id where ct.city_auto_id=c.city and c.user_id=".$userid);

$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
       $outp .= '{"street":"'  . $row["street"] . '",';
       $outp .= '"stateName":"'  . $row["state_name"] . '",';
       $outp .= '"country":"'  . $row["nicename"] . '",';
       $outp .= '"zip":"'  . $row["zip_code"] . '",';
       $outp .= '"name":"'  . $row["name"] . '",';
        $outp .= '"phone":"'  . $row["phone"] . '",';
		$outp .= '"email":"'  . $owner_mail . '",';
	   $outp .= '"city":"'. $row["city_name"]     . '"}'; 
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
