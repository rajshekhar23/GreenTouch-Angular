<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$query ="select distinct product.id,product.prod_group,prod_gdes,userid, prod_group_name as cat_name,prod_name,unit_price_unit,
unit_price,photo1,prod_quantitytype,prod_briefdes as prod_briefdes from product where userid=".$userid."";

$result = $conn->query($query);

$res = [];
if(mysqli_num_rows($result) > 0){
		while($row = $result->fetch_array(MYSQLI_ASSOC)) {
			$res[] = $row;
		}
		echo json_encode($res);
	} else {
		echo json_encode($res);
	}

$conn->close();
?>
