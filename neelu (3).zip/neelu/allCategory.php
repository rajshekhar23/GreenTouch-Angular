<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$result = $conn->query("select distinct prod_group, prod_group_name,photo1, group_concat(p.prod_name)as prod_name from product p where  prod_status=1 and userid=".$userid." group by prod_group limit 10" );

$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
		$outp .= '{"c_id":"'  . $row["prod_group"] . '",';
		$outp .= '"c_name":"'  . $row["prod_group_name"] . '",';
		$outp .= '"prod_name":"'  . $row["prod_name"] . '",';
		$outp .= '"c_img":"'. $row["photo1"].'"}'; 
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
