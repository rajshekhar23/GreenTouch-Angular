
<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
$id = $_GET['categoryId'];
//echo "select category.id,cat_img from category join product on category.id=product.prod_category where userid=".$userid." limit 10";

$result = $conn->query("select  prod_group, prod_name, photo1 from product where userid=".$userid." limit 10" );
 
$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
		$outp .= '{"c_id":"'  . $row["prod_group"] . '",';
		$outp .= '"c_name":"'  . $row["prod_name"] . '",';
		$outp .= '"c_img":"'. $row["photo1"].'"}'; 
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
