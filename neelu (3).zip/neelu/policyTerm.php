<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$result = $conn->query("select company_intro, terms_con from company where user_id=".$userid);

$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
		$outp .= '{"comp_policy":"'  . preg_replace("/[\r\n]+/", "<br />", $row["company_intro"]) . '",';
        
        //echo $row["prod_briefdes"];
		$outp .= '"comp_term":"'.  preg_replace("/[\r\n]+/", "<br />", $row["terms_con"]).'"}'; 
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
