<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$query ="select user_id,COM_brochure from company where user_id=".$userid."";

$result = $conn->query($query);

$res;
if(mysqli_num_rows($result) > 0){
		$row = $result->fetch_array(MYSQLI_ASSOC);
		$res = $row;
		echo json_encode($res);
		$conn->close();
}
?>
