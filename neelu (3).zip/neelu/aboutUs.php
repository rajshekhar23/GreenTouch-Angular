<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$result = $conn->query("select company_policy from company where user_id=".$userid);

$outp = "";
while($row = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
		$outp .= '{"company_policy":"'  . preg_replace("/[\r\n]+/", "<br />", $row["company_policy"]) . '"}';
}
$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
