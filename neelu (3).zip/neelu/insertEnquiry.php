<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods:POST
");

header("Access-Control-Allow-Headers:  content-type,accept");
$request_body = file_get_contents('php://input');
$data = json_decode($request_body,true);


$req[0]=$data["type"];
$req[1]=$data["msg"];
$req[2]=$data["id"];
$req[3]=$data["name"];
echo "RESTE";
echo $req[0];
echo $req[1];
echo $req[3];
echo $req[2];
$query ="";
if($req[0]=="email"){

	$query = "insert into enquiries(msg, email, name ,to_mail,from_mail,sub,del_status,phone) values ('".$req[1]."','".$req[2]. "','".$req[3]. "',' ',' ',' ',0,' ')";


}else if($req[0]=="SMS"){

	$query = "insert into enquiries(msg, phone, name,to_mail,from_mail,sub,del_status) values ('".$req[1]."','".$req[2]. "','".$req[3]. "',' ',' ',' ',0)";

}else {

	$query = "insert into enquiries(msg, enquiry, name ,to_mail,from_mail,sub,del_status,phone) values ('".$req[1]."','".$req[2]. "','".$req[3]. "',' ',' ',' ',0,'')";

}


echo $query;

if($data["type"]!=""){
	$result = $conn->query($query);
}



$outp = "";

$outp ='['.$outp.']';
$conn->close();
echo($outp);
?>
