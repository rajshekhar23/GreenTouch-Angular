<?php
require_once('dbConnect.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$query ="select distinct product.prod_group,prod_group_name,prod_gdes from product where userid=".$userid."";

$result = $conn->query($query);

$resInner = [];
if(mysqli_num_rows($result) > 0){
		while($row = $result->fetch_array(MYSQLI_ASSOC)) {
			$a['prod_group'] = $row['prod_group'];
			$a['prod_group_name'] = $row['prod_group_name'];
			$a['prod_gdes'] = $row['prod_gdes'];
			$query1 ="select prod_name,prod_briefdes,unit_price_unit,unit_price,photo1 from product where userid=".$userid." and prod_group=". $row['prod_group'] ." ";	
			$result1 = $conn->query($query1);
			$innerRow = [];
			while($row1 = $result1->fetch_array(MYSQLI_ASSOC)){
				$innerRow[] = $row1;
			}
			$a['products'] = $innerRow;
			$resInner[] = $a;
		}
		echo json_encode($resInner);
	} else {
		echo json_encode($resInner);
	}

$conn->close();
?>
